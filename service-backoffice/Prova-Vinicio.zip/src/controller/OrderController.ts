import { Order } from '../entity/Order';
import { Request, Response } from "express";
import { TypeORMError } from "typeorm";

class OrderController {

    public async index(request: Request, response: Response) {
        try {
            const brands = await Order.find();

            return response.json(Order);
        } catch (e) {
            const error = e as TypeORMError;
            return response.status(500).json({message: error.message});
        }
    }

    public async create(request: Request, response: Response) {
        try {
            const brand = await Order.save(request.body);

            return response.status(201).json(Order);
        } catch (e) {
            const error = e as TypeORMError;
            return response.status(500).json({message: error.message});
        }
    }

    public async show(request: Request, response: Response) {
        try {
            
            const {id} = request.params;

            if (!id) {
                return response.status(400).json({message: 'Parâmetro ID não informado'})
            }

            const found = await Order.findOneBy({
                id: Number(id)
            });

            if (!found) {
                return response.status(404).json({message: 'Recurso não encontrado'})
            }

            return response.json(Order);
        } catch (e) {
            const error = e as TypeORMError;
            return response.status(500).json({message: error.message});
        }
    }

    public async canceledDate(request: Request, response: Response){
        canceledDate = new Date();
        try {
            var canceledDate = await Order.save(request.body);

            return response.status(201).json(canceledDate);
        } catch (e) {
            const error = e as TypeORMError;
            return response.status(500).json({message: error.message});
        }
    }

}

export default new OrderController();